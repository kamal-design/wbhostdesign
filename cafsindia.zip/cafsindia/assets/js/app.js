//Preloader
$(window).on("load", function () {
  "use strict";
  setTimeout(function () {
    $(".preloader").fadeOut().delay(1000);      
  }, 1000);
});

//header
window.addEventListener("scroll", function () {
  const header = document.querySelector("header");
  header.classList.toggle("sticky", window.scrollY > 0);
});

//menu
$(".menu-button").on("click", function () {
  $(".menu-button .line:nth-of-type(1)").toggleClass("line-1");
  $(".menu-button .line:nth-of-type(2)").toggleClass("line-2");
  $(".menu-button .line:nth-of-type(3)").toggleClass("line-3");
  $(data - target).toggleClass("show");
  return false;
});

//wow
var res_wid = $(window).width();
if (res_wid > 1024) {
  var wid = $(window).width();
  var hei = $(window).height();
  $(".window_open")
    .css("width", wid + "px")
    .css("height", hei + "px");
  $("* .sizer")
    .css("width", wid + "px")
    .css("height", hei + "px");
}
new WOW().init();


$(document).ready(function(){
  $(".bannerslide").owlCarousel({
    loop: true,
    nav: true,
    dots: false,
    autoplay: true,
    autoplayTimeout: 7500,
    smartSpeed: 1500,
    animateOut: "fadeOut",
    animateIn: "fadeIn",
    items: 1,
    rtl: false,
    singleItem: true,
    fallbackEasing: "swing",
    refreshClass: "owl-refresh",
    loadedClass: "owl-loaded",
    loadingClass: "owl-loading",
    stagePadding: 0,
    navText: [
      '<i class="fa fa-angle-left fa-lg"></i>',
      '<i class="fa fa-angle-right fa-lg"></i>',
    ],
    responsiveClass: true,
    responsive: {
      0: {
        items: 1,
      },
      768: {
        items: 1,
      },
      1000: {
        items: 1,
      },
    },
  });
  $(".customerreview").owlCarousel({
    loop: true,
    nav: false,
    dots: true,
    autoplay: true,
    autoplayTimeout: 5000,
    smartSpeed: 1500,
    animateOut: "fadeOut",
    animateIn: "fadeIn",
    items: 1,
    rtl: false,
    singleItem: true,
    fallbackEasing: "swing",
    refreshClass: "owl-refresh",
    loadedClass: "owl-loaded",
    loadingClass: "owl-loading",
    stagePadding: 0,
    margin: 20,
    stagePadding: 8,
    navText: [
      '<i class="fa fa-angle-left fa-lg"></i>',
      '<i class="fa fa-angle-right fa-lg"></i>',
    ],
    responsiveClass: true,
    responsive: {
      768: {
        items: 1,
        margin: 10,
        stagePadding: 10,
      },
      992: {
        items: 1,
        margin: 10,
        stagePadding: 10,
      },
      1200: {
        items: 1,
        margin: 10,
        stagePadding: 10,
      },
      1400: {
        items: 1,
        margin: 10,
        stagePadding: 10,
      },
    },
  });
});
